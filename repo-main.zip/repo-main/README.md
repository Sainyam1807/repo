# Multi-Platform Matrix Build Demo (25376c2)
This repository demonstrates a multi-platform matrix build with artifact uploads.

**Email:** 24f1001256@ds.study.iitm.ac.in
